#ifndef XICON_H
#define XICON_H

extern char **x11_xpm;

#endif // XICON_H
